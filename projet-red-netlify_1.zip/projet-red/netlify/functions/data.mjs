import { getStore } from "@netlify/blobs";

export default async (req) => {
  const store = getStore("projet-red");

  if (req.method === "GET") {
    const data = await store.get("data", { type: "json" });
    return new Response(JSON.stringify(data ?? null), {
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
    });
  }

  if (req.method === "PUT" || req.method === "POST") {
    try {
      const body = await req.json();
      if (!body || !Array.isArray(body.sessions)) {
        return new Response(JSON.stringify({ ok: false, error: "format invalide" }), { status: 400 });
      }
      await store.setJSON("data", body);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" }
      });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "JSON invalide" }), { status: 400 });
    }
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config = { path: "/api/data" };
