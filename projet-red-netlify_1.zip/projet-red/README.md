# PROJET RED — Registre des séances (Netlify)

Site de stats du Projet RED avec **stockage partagé sur le serveur** :
toute séance ajoutée via le formulaire est sauvegardée dans Netlify Blobs
et visible en direct par tous les visiteurs du site.

## Contenu

```
index.html                  → le site
netlify/functions/data.mjs  → l'API (/api/data) qui lit/écrit le stockage
netlify.toml                → config Netlify
package.json                → dépendance @netlify/blobs
```

## Déploiement (important !)

Le stockage partagé nécessite que Netlify **construise** le projet pour
installer la dépendance `@netlify/blobs`. Le simple glisser-déposer du
dossier sur app.netlify.com ne suffit PAS.

### Option A — via GitHub (recommandé)
1. Crée un dépôt GitHub et pousse ce dossier dedans.
2. Sur app.netlify.com → "Add new site" → "Import an existing project".
3. Choisis le dépôt. Laisse les réglages par défaut (le netlify.toml fait tout).
4. Deploy. C'est fini.

### Option B — via Netlify CLI
```
npm install -g netlify-cli
cd projet-red
npm install
netlify deploy --prod
```

## Vérifier que ça marche

Ouvre le site : le badge en haut à droite doit afficher
**"● stockage partagé actif"** (vert). S'il affiche "○ mode local" en
orange, c'est que la fonction n'est pas déployée (voir ci-dessus).

Tu peux aussi tester l'API directement : `https://TON-SITE.netlify.app/api/data`
doit renvoyer du JSON.

## Fonctionnement

- Au premier chargement, le site initialise le serveur avec les séances 1 à 4.
- Chaque "Enregistrer la séance" recharge d'abord la version serveur
  (pour ne pas écraser un ajout fait par quelqu'un d'autre) puis sauvegarde.
- Le bouton "Actualiser depuis le serveur" (onglet Rapports) récupère
  les derniers ajouts.
- Exporter/Importer JSON reste disponible comme sauvegarde de secours.
  Un import remplace les données du serveur.

## Note

L'API est ouverte : toute personne ayant l'URL du site peut ajouter des
séances (c'est le but). Si un jour tu veux restreindre l'écriture, il
faudra ajouter un mot de passe dans la fonction data.mjs — demande-moi.
